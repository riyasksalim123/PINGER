import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { Backendservice } from '../../providers/backendservice';



@Component({
  selector: 'page-my-page',
  templateUrl: 'my-page.html'
})
export class MyPagePage {

    data: any;

    constructor(public navCtrl: NavController,
               public backend: Backendservice)

    {

       


    }

  ionViewDidLoad() {
      console.log('Hello MyPagePage Page');
      this.backend.load('../assets/data/data.json').then(mapData => {
          this.data = mapData;

      })
  }

}
